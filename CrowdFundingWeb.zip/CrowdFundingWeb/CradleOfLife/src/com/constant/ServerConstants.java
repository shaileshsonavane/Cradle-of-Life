package com.constant;

import java.net.URLEncoder;

import com.helper.StringHelper;

public class ServerConstants {
	public static final String db_driver = "com.mysql.jdbc.Driver";
	public static final String db_user = "root";
	public static final String db_pwd = "";
	public static final String db_url = "jdbc:mysql://localhost/crowdfunding";
	
	public static final String SMS_URL = "";
	public static final String currbal = "0.0";
}
