package com.helper;

public class NGOModel {
	String ngoid, ngoname, location, lat, longt;

	public String getNgoid() {
		return ngoid;
	}

	public void setNgoid(String ngoid) {
		this.ngoid = ngoid;
	}

	public String getNgoname() {
		return ngoname;
	}

	public void setNgoname(String ngoname) {
		this.ngoname = ngoname;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getLat() {
		return lat;
	}

	public void setLat(String lat) {
		this.lat = lat;
	}

	public String getLongt() {
		return longt;
	}

	public void setLongt(String longt) {
		this.longt = longt;
	}

}
